/** Reviewed Host half of the trusted-installation fixture Bundle. */
import type { Context } from '@deepseek-ai/cordis';
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** Deterministic Host evidence supplied only while the fixture is active. */
        pluginCenterFixture: {
            readonly status: 'running';
            readonly capability: 'workspace-tools';
        };
    }
}
/** Provide observable Host evidence for post-restart verification. */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map