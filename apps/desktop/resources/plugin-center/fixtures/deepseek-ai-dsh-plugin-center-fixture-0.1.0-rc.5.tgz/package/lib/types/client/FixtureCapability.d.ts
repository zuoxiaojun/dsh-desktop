/** Visible browser capability contributed by the reviewed fixture Bundle. */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
type FixtureLocaleKey = 'nav' | 'title' | 'description' | 'running';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        pluginCenterFixture: FixtureLocaleKey;
    }
}
export declare const inject: string[];
/** Register one first-level navigation action and observable capability page. */
export declare function apply(ctx: ClientContext): void;
export {};
//# sourceMappingURL=FixtureCapability.d.ts.map