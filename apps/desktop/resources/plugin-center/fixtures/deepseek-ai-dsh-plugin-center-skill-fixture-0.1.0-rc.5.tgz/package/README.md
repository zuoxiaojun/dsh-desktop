# @deepseek-ai/dsh-plugin-center-skill-fixture

English | [中文](README.zh.md)

Reviewed development fixture for the Desktop Plugin Center Skill-pack install path. Its Bundle patch activates one Host provider, which registers the globally discoverable `fixture-harness-basics` Skill. Production features must not depend on this fixture.

## Model Experience

Adds one deterministic fixture Skill only after the Bundle is installed and active.

#### KV Cache effect

The Skill catalog changes after installation; ordinary prompts remain unchanged until a consumer includes or invokes that Skill.
