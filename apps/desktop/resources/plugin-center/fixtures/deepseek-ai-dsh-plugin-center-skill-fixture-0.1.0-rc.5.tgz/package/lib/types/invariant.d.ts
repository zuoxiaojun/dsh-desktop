/** Package-owned invariant companion for the reviewed Skill fixture. */
import type { Context } from '@deepseek-ai/cordis';
export declare const name = "plugin-center-skill-fixture-invariant";
export declare const inject: string[];
export declare const apply: (ctx: Context) => Promise<() => void>;
//# sourceMappingURL=invariant.d.ts.map