/** Reviewed Skill-pack fixture loaded through an ordinary DSH Bundle. */
import type { Context } from '@deepseek-ai/cordis';
export declare const inject: string[];
/** Register one deterministic globally discoverable Skill. */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map