# @deepseek-ai/dsh-plugin-center-skill-fixture

[English](README.md) | 中文

Desktop 插件中心 Skill pack（技能包）安装链路的受审查开发测试包。其 Bundle patch 激活一个 Host provider（宿主提供方），后者注册全局可发现的 `fixture-harness-basics` Skill。生产功能不得依赖此测试包。

## 模型体验

只有在 Bundle 安装并激活后，才新增一个确定性的测试 Skill。

#### KV Cache 影响

安装后 Skill 目录会变化；普通提示词不变，直到消费方纳入或调用该 Skill。
